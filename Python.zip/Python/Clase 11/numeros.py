import random

a = 1
b = 1.5
c = 3+5j

n = 3e5
m = 12E4

#print(type(m))

r = random.randrange(1,10)
print(r)