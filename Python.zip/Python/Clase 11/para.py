n = 5
# for <variable_en_iteracion> in <variable_iterativa>
"""
for i in [1,2,3,4,5]:
    print(i)
"""
# range(n) - > [0,...,n-1]
"""
for i in range(n):
    print(i)
"""

# range(a,n) - > [a,...,n-1]
for i in range(1,n+1):
    print(i)

animales = ["leon", "tigre", "oso", "aguila", "dragon"]

for i in animales:
    print(i)

