listilla = [1,2,3,4,5]

#con numeros positivos, tendremos el valor de la posicion marcada
print(listilla[1])

#con numeros negativos, tendremos el valor de la posicion inversa
print(listilla[-1])

#con rangos [n:m], tendremos los valores entre las posiciones
print(listilla[2:5])

# con rango incompletos, tener los valores hasta el valor agregado
print(listilla[2:])
print(listilla[:3])

# con rangos negativos, 
print(listilla[-3:-1])

 
print(listilla[-3:])