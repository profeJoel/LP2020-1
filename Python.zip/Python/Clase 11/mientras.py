e=5

while e>0:
    print(e)
    #e = e - 1
    e -= 1
    if e == 2:
        #break
        continue
else:
    print("Se salio de ciclo")
print("Fuera de Ciclo")