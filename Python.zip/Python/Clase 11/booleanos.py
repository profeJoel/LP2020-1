a = True
b = False
c = None

x = 0 # si es 0 el booleano o condicion es falsa
# y = "booleanismo" # cualquier texto es verdadero
y = "" # si es vacio, entonces es Falso

#z = [1,2,3] # cualquier array con contenido es verdadero
z = [] # si es vacio, entonces es Falso


if c:
    print("Si")
else:
    if c==False:
        print("No")
    else:
        print("Nulo")

print("Fuera del IF")