print("Hola Mundo!!!")
print("Hola Clase!!!")
# tipos de datos
x = 1
y = 5.5
t = "hola"
print(type(x))
print(type(y))
print(type(t))

#Casting de datos
"""
y2 = int(y)
print(y2)
yChar = str(y)
print(type(yChar))
print("el valor de "+str(y))

xf = float(x)
print(xf)
"""
print("Fin del Codigo")


