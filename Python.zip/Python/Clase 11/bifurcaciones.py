# igual ==
# not es igual !=
# menor <
# mayor >
# mayor igual >=
# menor igual <=

a = 5
b = 10

if a<b:
    print("Si a es Menor")
elif a==b:
    print("Son iguales")
else:
    print("B es Menor")

#if a==b: print("Son iguales")

# expresion por Verdadero | consulta | expresion por negativo

#print("SOn iguales") if a==b else print("NO lo son")

# and or not

"""
if not (a<b and b<8):
    print("Si")
else:
    print("NO")
"""
a=20
if a>10:
    pass
else:
    print("si pasa")