# def nombre_funcion(arg1, ...):
#     ...
#     return arg1

#Operadores + - * / ** // %
def hace_doble(x):
    return x*2

def hace_cuadrado(x):
    return x**2

def dividir(a,b):
    return a/b
def dividir_entero(a,b):
    return a//b

print(dividir(5,2))
print(dividir_entero(5,2))
#print(hace_doble(4))
#print(hace_cuadrado(4))