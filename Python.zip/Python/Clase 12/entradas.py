# 3.x input(arg_texto) - > devuelve el texto en el buffer de entrada

a = int(input("Ingrese un valor:"))
a +=1
print("Este es el valor: "+str(a))

#2.7 < raw_input() - > no se usa actualmente.